let size = 15;
let O_size = 16;

let $center = document.querySelector("#center");
let $header = document.querySelector("#header");
let $table = document.createElement("table");
	$table.setAttribute("id","intable");

let $table2 = document.createElement("table");
	$table2.setAttribute("id","outtable");

let $omokpan = document.querySelector("#omokpan");
let $omokpan_O = document.querySelector("#omokpan_O");



let $black = "⚫";
let $white = "⚪";

let $tdList = [];
let $O_tdList = [];

let turn = true;
let endCheck = false;
let first = true;

let time = 61;
let timer = null;
// setInterval 함수로 타이머를 계속해서 올릴 예정

let $P_second = document.querySelector("#P_second");
let $C_second = document.querySelector("#C_second");

let $turn_T_nameP = document.querySelector(".turn_T_nameP");
let $turn_T_nameC = document.querySelector(".turn_T_nameC");


let $h1 = document.createElement("h1");
$h1.innerText = "오목게임"
$header.append($h1);

function times(){
	clearInterval(timer);
	timer = setInterval(times,1000);
		if(time == 0){
			alert("1분이 경과되서 상대턴으로 넘어갑니다!");
			turn = !turn;
			time = 61;
		}
		time--;
		if(turn){
			$P_second.innerText = time;
			$C_second.innerText = "";
			$turn_T_nameP.style.backgroundColor = "red";
			$turn_T_nameC.style.backgroundColor = "";
		} else {
			$C_second.innerText = time;
			$P_second.innerText = "";
			$turn_T_nameP.style.backgroundColor = "";
			$turn_T_nameC.style.backgroundColor = "red";	
		}
} 

function turn_Time(){
	clearInterval(timer);
	timer = setInterval(times,1000);
	
}

function garo(y,nowTurn){
	let count =0;
	let check = false;
	for(let i=0; i<size; i++){
		
		if($tdList[y][i].innerText == nowTurn){
			count++;
		} else {
			count =0;
		}

		if(count == 5){
			check = true;
			return check;
		}
	}

}

function sero(x,nowTurn){
	let count =0;
	let check = false;
	for(let i=0; i<size; i++){
		
		if($tdList[i][x].innerText == nowTurn){
			count++;
		} else {
			count =0;
		}

		if(count == 5){
			check = true;
			return check;
		}
	}
	
}

function diagonal_LeftRight(y,x,nowTurn){ //  왼쪽에서 오른쪽 밑으로 우선 오른쪽에서 왼쪽위로 쭉가면서 그 대각선줄의 첫번째로 이동해준다
	let tempY = y;
	let tempX = x;
	
	while(true){
		
			if(tempY <= 0 || tempX <= 0){
				break;
			}
		tempY--;
		tempX--;
	}
	
	let count = 0;
	let check = true;
	
	while(true){
		if($tdList[tempY][tempX].innerText == nowTurn){
			count ++;
		} else {
			count =0;
		}
		if(count == 5){
			return check;
		}
		if(tempY >= size-1 || tempX >= size-1){
			break;
		}
		tempY++;
		tempX++;
	}
	
}

function diagonal_RightLeft(y,x,nowTurn){  // 오른쪽에서 왼쪽 밑으로 우선 오른쪽 위로 쭉가서 좌표로 이동 그다음 왼쪽 밑으로 이동하면서 체크
	let tempY = y;
	let tempX = x;
	while(true){

			if(tempY <= 0 || tempX >= size-1){
				break;
			}
			tempY--;
			tempX++;
	}
	
	let count = 0;
	let check = true;
	
	while(true){
		if($tdList[tempY][tempX].innerText == nowTurn){
			count ++;
		} else {
			count =0;
		}
		if(count == 5){
			return check;
		}
		if(tempY == size-1 || tempX == 0){
			break;
		}
		tempY++;
		tempX--;
	}
}

function check(y,x,nowTurn){

	let check = [garo(y,nowTurn) ,sero(x,nowTurn), diagonal_LeftRight(y,x,nowTurn),diagonal_RightLeft(y,x,nowTurn)];

	for(let i=0; i<check.length; i++){
		
		if(check[i]){
			endCheck = true;
			break;
		}
	}
	
}


function Eventclick(e){ //클릭한 위치 찾기 
	turn_Time();
	let nowTurn = turn ? "⚫" : "⚪";

	let y = 0;
	let x = 0;

	for(let i=0; i<size; i++){

		for(let j=0; j<size; j++){
			if(e.target==$tdList[i][j]){
				y = i;
				x = j;
			}
		}
	}
	
	if(turn){
	e.target.innerText = nowTurn;
	e.target.removeEventListener("click",Eventclick);
	e.target.style.cursor = "default";
	} else {
    e.target.innerText = nowTurn;
    e.target.removeEventListener("click",Eventclick);
    e.target.style.cursor = "default";
	}
	check(y,x,nowTurn);
	if(endCheck){
		end();
	}
    time = 60;
	turn = !turn;
}

function init(){
	
	for(let i=0; i<O_size; i++){
		let $tr = document.createElement("tr");
		let $tdList_Temp = [];

		for(let j=0; j<O_size; j++){
			let $td = document.createElement("td");
			$td.setAttribute("id","out");
			$tdList_Temp.push($td);
			$tr.append($td);
		}
		$O_tdList.push($tdList_Temp);
		$table2.append($tr);
	}
	$omokpan_O.append($table2);

	for(let i=0; i<size; i++){
		let $tr = document.createElement("tr");
		let $tdList_Temp = [];

		for(let j=0; j<size; j++){
			let $td = document.createElement("td");
			$td.innerText = "";
			$td.setAttribute("id","in");
			$td.addEventListener("click",Eventclick);
			$td.style.cursor = "pointer";
			$tdList_Temp.push($td);
			$tr.append($td);
		}
		$tdList.push($tdList_Temp);
		$table.append($tr);
	}
	$omokpan.append($table);
}

function end(){

    clearInterval(timer);
	let black = document.querySelector(".turn_T_nameP");
	let white = document.querySelector(".turn_T_nameC");

	document.querySelector("#end_Game").innerText = turn ? `${black.innerText} 님이 승리하셨습니다!`: `${white.innerText} 님이 승리하셨습니다!`;
	document.querySelector("#end_Game").style.color = "white";
	document.querySelector("#end_Game").style.width="100%";
	document.querySelector("#end_Game").style.backgroundColor="black";
	document.querySelector("#end_Game").style.fontSize="50px";
	document.querySelector("#end_Game").style.textAlign="center";
	
	let $tds = document.querySelectorAll("#in");
	
	for(let i=0; i<$tds.length; i++){
		$tds[i].removeEventListener("click",Eventclick);
		$tds[i].style.cursor = "default"
	}
	
}

init();
