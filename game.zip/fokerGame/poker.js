class Card {
	num;
	pattern;
	color;

	constructor(num,pattern,color){
		this.num = num;
		this.pattern = pattern;
		this.color = color;
	}

	printdata(){
		document.write(this.num + " " + this.pattern + " " + this.color+"<br>");
		
	}
}

let patternList = ["Spade","clover","heart","Diamond"];
let color = ["black","red"];
let cardList = []; //클래스로 카드를 만들어서 배열에 담습니다.

let comCards = [];
let $comCards = [];

let playerCards = [];
let $playerCards = [];

let index = 0;
let $index_C = 1;
let $index_P = 1; 

let $cardList = [];


let $wincardList = ["탑카드","원페어", "투페어", "트리플","스트레이트","백스트레이트","마운틴","플러쉬","풀하우스","포카드","스트레이트플러쉬","백스트레이트플러쉬","로얄스트레이트플러쉬"];

let nextTurnbox = document.querySelector(".betbox");
let endTurnbox = document.querySelector(".betbox2");
let $player_money = document.querySelector("#player_money");
let $coms_money = document.querySelector("#com_money");
let $pan_Money = document.querySelector("#pan_money");
let $com_card = document.querySelector("#com_card");
let $player_card = document.querySelector("#player_card");


let player_money = 80000000;
let coms_money = 150000000;
let pan_money = 500000;

let $half = document.querySelector("#half");
let $double = document.querySelector("#double");
let $bbing = document.querySelector("#bbing");
let $check = document.querySelector("#check");
let $die = document.querySelector("#die");
let $all_in = document.querySelector("#all_in");


let $reset = document.querySelector("#reset");
let $popup = document.querySelector("#popup");

let turn = 1;

let p1_winScore = [0,0];
let com_winScore = [0,0];
let end = 0;

function Half(){
	if(turn >5) return;
	
    if((player_money - pan_money *1.5)  <0){
        alert("돈이 모자랍니다.");
        return
    }
    let temp = pan_money;
    pan_money += pan_money * 3;
    player_money -= temp *1.5;
	coms_money -=temp *1.5;
    play_turn();
}

function double(){
	if(turn >5) return;
    if((player_money - pan_money*2)  < 0){
        alert("돈이 모자랍니다.");
        return
    }
    
    let temp = pan_money;
    pan_money += pan_money * 4;
    player_money -= temp *2;
	coms_money -=temp *2;
    play_turn();
}

function Allin(){
	if(turn >5) return;

    let temp = pan_money;
    pan_money += player_money;
	coms_money -= player_money;
    player_money -= player_money;
    play_turn();

}

function Check(){
	if(turn >5) return;
    play_turn();
}

function Bbing(){
	if(turn >5) return;
    if((player_money - 500000)  < 0){
        alert("돈이 모자랍니다.");
        return
    }

    pan_money += 500000;
    player_money -= 500000;
	coms_money -=500000;
    play_turn();
}


function Die(){
Reset();
}

function indexPlus(){
	index++;
}
function index_cPlus(){
	$index_C++;
}
function index_pPlus(){
	$index_P++;
}

function addCard(){
	return cardList[index];
}

function firstTurn(){
	for(let i=0; i<3; i++){
		let card = addCard();
		comCards.push(card);
		let cTd = document.querySelector(`#cc${$index_C}`);
		cTd.append($cardList[index]);
		indexPlus();
		index_cPlus()
	}

	for(let i=0; i<3; i++){
		let card = addCard();
		playerCards.push(card);
		let pTd = document.querySelector(`#cp${$index_P}`);
		pTd.append($cardList[index]);
		indexPlus();
		index_pPlus()
	}
}

function turn_comOne(){
	let card = addCard();
	comCards.push(card);
	let cTd = document.querySelector(`#cc${$index_C}`);
	$comCards.push($cardList[index]);
	cTd.append($cardList[index]);
	indexPlus();
	index_cPlus();
}

function back_turnOne(){
	let $backcard = document.createElement("img");
	$backcard.src = `backcard/back.jpg`;
	$backcard.setAttribute("class","card");
	let card = addCard();
	comCards.push(card);
	$comCards.push($cardList[index]);
	let cTd = document.querySelector(`#cc${$index_C}`);
	cTd.append($backcard);
	indexPlus();
	index_cPlus();
}

function player_turnOne (){
	let card = addCard();
	playerCards.push(card);
	let pTd = document.querySelector(`#cp${$index_P}`);
	$playerCards.push($cardList[index]);
	pTd.append($cardList[index]);
	indexPlus();
	index_pPlus()
}

function lastcom_cardOpen(){
	let parent = document.querySelector("#cc1");
	let child = parent.querySelector(`:first-child`);
	parent.removeChild(child);
	parent.append($comCards[0]);

	parent = document.querySelector("#cc2");
	child = parent.querySelector(`:first-child`);
	parent.removeChild(child);
	parent.append($comCards[1]);

	parent = document.querySelector("#cc7");
	child = parent.querySelector(`:first-child`);
	parent.removeChild(child);
	parent.append($comCards[6]);
}

function suffle(){
	
	for(let i=0; i<10000; i++){
		let r = Math.floor(Math.random()*cardList.length);
		let r1 = Math.floor(Math.random()*cardList.length);
		let temp = cardList[r];
		cardList[r] = cardList[r1];
		cardList[r1] = temp;
		let tempI = $cardList[r];
		$cardList[r] = $cardList[r1];
		$cardList[r1] = tempI;
	}
}

function flush(cards){

	let score = 0;
	let result = [false, 0];
	let patternList_Check = [0,0,0,0];
	let color_Check = [0,0];
	let pattern = 0;
	let mx = 0;
	for(let i=0; i<cards.length; i++){
		
		for(let j=0; j<patternList.length; j++){
			if(cards[i].pattern == patternList[j]){
				patternList_Check[j]++;
				break;
			}
		}

		for(let j=0; j<color.length; j++){
			if(cards[i].color == color[j]){
				color_Check[j]++;
				break;
			}
		}
	}

	for(let i=0; i<patternList_Check.length-2; i++){
		if(patternList_Check[i] >=5){
			score++;
			pattern = i;
			break;
		}
	}

		if(color_Check[0] >= 5){
			score++;
		}
	

	if(score == 2){
		result[0] = true;
	} 
	score = 0;


	for(let i=patternList_Check.length-2; i<patternList_Check.length; i++){
		if(patternList_Check[i] >=5){
			pattern = i;
			score++;
		}
	}


		if(color_Check[1] >= 5){
			score++;
		}
	

	if(score == 2){
		result[0] = true;
	}
	
	if(result){
		for(let i=0; i<cards.lengtgh; i++){
			if(cards[i].pattern == patternList_Check[pattern]){
				if(mx < cards[i].num){
					mx = cards[i].num;
				}
			}
		}
	}
	

	return result;
}


function s_pCheck(cards,check_pokerCards){

	for(let i=0; i<cards.length; i++){
		check_pokerCards[cards[i].num]++;
	}
	check_pokerCards[0] = check_pokerCards[14];
}

function pair(pokerCards){
	let mx_score =0;
	let one_Pair = 0;
	let Triple = 0;
	let Fourcard = 0;
    let mx_Number = 0;
	let highNumber = 1;
	let check = false;
	console.log(pokerCards);
	for(let i=1; i<pokerCards.length; i++){

		if(pokerCards[i] == 2){
			one_Pair++;

			if(highNumber <=1 ){
			highNumber = 1;
			mx_Number = i;
			if(i == 1){
				mx_Number = 14;
			}
			}
			check = true;

		} else if(pokerCards[i] == 3){
			Triple++;
			
			if(highNumber <=3 ){
				highNumber = 3;
				mx_Number = i;
				if(i == 1){
					mx_Number = 14;
				}

			}	
			check = true;

		} else if(pokerCards[i] == 4){
			Fourcard++;
			highNumber = 4;
			mx_Number = i;
			check = true;

		}

		if(pokerCards[i] >=1 && check == false){
	
			mx_Number = i;
		
		}
		
	}

	if(Fourcard == 1){
		mx_score = 9;
	} else if(Triple >=1 && one_Pair >= 1){
		mx_score = 8;
	} else if(Triple >=1 && one_Pair == 0){
		mx_score = 3;
	} else if(Triple == 0 && one_Pair >= 2 ){
		mx_score = 2;
	} else if(Triple == 0 && one_Pair  == 1 ){
		mx_score = 1;
	} else if(Triple == 0 && one_Pair  == 0 ){
		mx_score = 0;
	}

	return [mx_score,mx_Number];
}

function straight(pokerCards){

	let check = 0;
	let count =0;
	let first_Num = 0;
	let last_Num = 0;
	
	for(let i=1; i<pokerCards.length; i++){

		if(pokerCards[i] >= 1){
			count++;
		} else {
			count = 0;
		}

		if(count >=5){
			last_Num = i;
			first_Num = i-4;
			check = 2;
			if(first_Num == 1){
				check = 1;
				last_Num = 14;
				break;
			}
			if(last_Num == 14){
				check = 14;
			}
		}
    }

	

	return [check,last_Num];
}

function result_score(flush_Check,straight_Check){

	let max_score = [0,0];


	if(flush_Check[0] && straight_Check[0] == 14){
		max_score[0] = 12;
		max_score[1] = straight_Check[1];
	} else if(flush_Check[0] && straight_Check[0] == 1){
		max_score[0] = 11;
		max_score[1] = straight_Check[1];
	} else if(flush_Check[0] && straight_Check[0] == true){
		max_score[0] = 10;
		max_score[1] = straight_Check[1];
	} else if(flush_Check[0] == false && straight_Check[0] == 14){
		max_score[0] = 6;
		max_score[1] = straight_Check[1];
	} else if(flush_Check[0] == false && straight_Check[0] == 1 ){
		console.log(flush_Check,straight_Check[0]);
		max_score[0] = 5;
		max_score[1] = straight_Check[1];
		
	} else if(flush_Check[0] == false && straight_Check[0] == 2){
		max_score[0] = 4;
		max_score[1] = straight_Check[1];
	}

	return max_score;
}


function lastCheck(cards){
	let mx_score = [0,0];
	
	let check_pokerCards = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	//					   [0,A,2,3,4,5,6,7,8,9,10,J,Q,K,A];
	let flush_Check = flush(cards); // 플러쉬일 경우에 true값 반환
	let flush_score = 0

    if(flush_Check[0]){
		flush_score = 7;
	}
	console.log("플러시체크"+flush_Check);

	s_pCheck(cards,check_pokerCards);
	
	let pair_Check = pair(check_pokerCards); // 점수로 반환 [0,0] d
	console.log("페어체크"+pair_Check);
	if(pair_Check[0] > flush_score){
		mx_score = pair_Check;
	} else {
		mx_score[0] = flush_score;
	}

	let straight_Check = straight(check_pokerCards); // 그냥 스트레이트면 2 반환 백스트레이트면 1, 마운틴이면 14 반환 ex[true,14]
	
	console.log("스트레이트체크 "+straight_Check);
	let straightFlush_Check = result_score(flush_Check,straight_Check);

	if(mx_score[0] < straightFlush_Check[0]){
		mx_score[0] = straightFlush_Check[0];
        mx_score[1] = straightFlush_Check[1];
	}
    

	return mx_score  // 위에서 걸러주고 최종 패를 찾아준다.
}

function handoutCards(){
	let p_index = 0;
	let c_index	= 0;

	while(p_index <4){
		for(let i=2; i<=14; i++){
			let card =new Card(i,patternList[p_index],color[c_index]);
			cardList.push(card);
			let imgElement = document.createElement("img");
			imgElement.src = `${patternList[p_index]}/${patternList[p_index]}_${i}.jpg`;
			imgElement.setAttribute("class","card");
			$cardList.push(imgElement);
		}
		p_index++;
		if(p_index==2){
			c_index++;
		}
	}
}

function check_money(){
    let $printP = player_money.toLocaleString();
    let $printC = coms_money.toLocaleString();
    let $printPan = pan_money.toLocaleString();
    
    document.querySelector("#player_money").innerText = $printP;
    document.querySelector("#com_money").innerText =  $printC;
    document.querySelector("#pan_money").innerText = "POT "+ $printPan;
}

function endTurn(){
	
    if(p1_winScore[0] > com_winScore[0] ){
        player_money += pan_money;
        alert(`플레이어승리! ${pan_money.toLocaleString()}원 획득!`);
     } else if(p1_winScore[0] < com_winScore[0]){
        coms_money += pan_money;
        alert(`컴퓨터승리! ${pan_money.toLocaleString()}원 획득!`);
     } else if(p1_winScore[0] == com_winScore[0]){
        if(p1_winScore[1] > com_winScore[1] ){
            player_money += pan_money;
            alert(`플레이어승리! ${pan_money.toLocaleString()}원 획득!`);
         } else if(p1_winScore[1] < com_winScore[1]){
            coms_money += pan_money;
            alert(`컴퓨터승리! ${pan_money.toLocaleString()}원 획득!`);
         } else if(p1_winScore[1] == com_winScore[1]){
            alert("무승부 돈을 반반 나눠 같습니다.");
			coms_money += pan_money/2;
			player_money += pan_money/2;
         }
     }
	 
	 check_money();
     clearInterval(end);
	 if(coms_money <= 0){
		alert("포커게임 제 1회 우승자 입니다!!");
	 } else if(player_money <=0){
		alert("F5를 눌러 다시 도전해보세요!");
	 }
	 $reset.addEventListener("click",Reset);
	 $reset.style.cursor = "pointer";
	 console.log("플레이어점수"+p1_winScore);
	 console.log("컴"+com_winScore);
}

function ardwin_Color(num){
	let $change_Td = document.querySelectorAll(".Winstd");
	$change_Td[$wincardList.length-1-num].style.color = "red";
}

function ardwin_Color_reset(){
	let $change_Td = document.querySelectorAll(".Winstd");
	for(let i=0; i<$change_Td.length; i++){
		$change_Td[i].style.color = "chartreuse";
	}
}

function play_turn(){
    check_money();
    if(turn == 5){
		$com_card.innerText = $wincardList[com_winScore[0]];
        lastcom_cardOpen();
        end = setInterval(endTurn,1000);
    } else if(turn == 4){
        back_turnOne();
        player_turnOne();
    } else {
        turn_comOne();
        player_turnOne();
    }

	p1_winScore = lastCheck(playerCards);
	com_winScore = lastCheck(comCards);
	$player_card.innerText = $wincardList[p1_winScore[0]];
	ardwin_Color(p1_winScore[0]);

    turn++;
}

function halfShowPopup(){
    $popup.style.display = 'block';
    $popup.style.display = 'flex';
    $popup.style.left = '1370px';
    $popup.style.bottom = '135px';
    $popup.innerText = (pan_money * 1.5).toLocaleString();

}

function doubleShowPopup(){
    $popup.style.display = 'block';
    $popup.style.display = 'flex';
    $popup.style.left = '1470px';
    $popup.style.bottom = '135px';
    $popup.innerText = (pan_money *2).toLocaleString();
}


function bbingShowPopup(){
    $popup.style.display = 'block';
    $popup.style.display = 'flex';
    $popup.style.left = '1570px';
    $popup.style.bottom = '255px';
    $popup.innerText = "500,000"

}

function hidePopup(){
    $popup.style.display = 'none';
}


function settingbox(){
    $half.addEventListener("click",Half);
    $double.addEventListener("click",double);
    $bbing.addEventListener("click",Bbing);
    $check.addEventListener("click",Check);
	$all_in.addEventListener("click",Allin);
    $die.addEventListener("click",Die);
    
    $half.addEventListener("mouseover",halfShowPopup);
    $half.addEventListener("mouseout",hidePopup);

    $double.addEventListener("mouseover",doubleShowPopup);
    $double.addEventListener("mouseout",hidePopup);

    $bbing.addEventListener("mouseover",bbingShowPopup);
    $bbing.addEventListener("mouseout",hidePopup);

	$wins = document.querySelector("#Wins");
	for(let i=$wincardList.length-1; i>=0; i--){
	let $tr = document.createElement("tr");
	let $td = document.createElement("td");
	$td.innerText = $wincardList[i];
	$td.setAttribute("class","Winstd");
	$tr.append($td);
	$wins.append($tr);
	}

}
function playGame(){
	$reset.style.cursor = "default";
	$reset.removeEventListener("click",Reset);
	check_money();
    pan_money = 500000; // 기본판돈
    player_money -= 500000;
    coms_money -= 500000;
	
	handoutCards();
	suffle();
	back_turnOne();
	player_turnOne();
	back_turnOne();
	player_turnOne();
	turn_comOne();
	player_turnOne();

	p1_winScore = lastCheck(playerCards);
	com_winScore = lastCheck(comCards);
	$player_card.innerText = $wincardList[p1_winScore[0]];
	ardwin_Color_reset();

}

function init(){
    settingbox();
	playGame();
}


function removeCard(){
    let $com_tr = document.querySelector("#com_Td");
    let $player_tr = document.querySelector("#p1_Td");
    let $com_tr_tds = $com_tr.getElementsByTagName('td');
    let $player_tr_tds = $player_tr.getElementsByTagName('td');
    
    Array.from($com_tr_tds).forEach(tdElement=> {
        // td 요소의 자식 이미지 요소 가져오기
        let imageElement = tdElement.querySelector('img');
        
        // 이미지 요소가 있는 경우 삭제
        if (imageElement) {
            tdElement.removeChild(imageElement);
        }
    });

    Array.from($player_tr_tds).forEach(tdElement=> {
        // td 요소의 자식 이미지 요소 가져오기
        let imageElement = tdElement.querySelector('img');
        
        // 이미지 요소가 있는 경우 삭제
        if (imageElement) {
            tdElement.removeChild(imageElement);
        }
    });
}

function Reset(){
	$com_card.innerText = "";
    cardList = [];
    $cardList = [];

    comCards = [];
    $comCards = [];

    playerCards = [];
    $playerCards = [];

    turn = 1;
    index =0;
    $index_C = 1;
    $index_P = 1;
    pan_money = 500000;
    removeCard();
    playGame();
    
}

init();

